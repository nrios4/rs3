# Table1.R
rm(list = ls())

# Change this working directory to the location of the SimResults folder.
setwd("C:/Users/nrios4/OneDrive - George Mason University - O365 Production/Desktop/rs3code/SimResults")

### Table A1 (Binomial, rho = 0)
bin_n200_active3 = read.csv("med_binomialn200p500rho0active3.csv")[,-c(1,4)]
bin_n200_active6 = read.csv("med_binomialn200p500rho0active6.csv")[,-c(1,4)]
rownames1 = c("RS3","RS3+SCAD","RS3+FPCS","Lasso","Elastic","BeSS","abess","SCAD")

tableA1 = cbind(bin_n200_active3, bin_n200_active6)
rownames(tableA1) = rownames1
round(tableA1,2)  # Table A1

### Table A2 (Gaussian, rho = 0)
gaus_n200_active3 = read.csv("med_gaussiann200p500rho0active3.csv")[,-c(1,4)]
gaus_n200_active6 = read.csv("med_gaussiann200p500rho0active6.csv")[,-c(1,4)]
rownames1 = c("RS3","RS3+SCAD","RS3+FPCS","Lasso","Elastic","BeSS","abess","SCAD")

tableA2 = cbind(gaus_n200_active3, gaus_n200_active6)
rownames(tableA2) = rownames1
round(tableA2,2)  # Table A2

### Table A3 (Binomial, rho = 0.5)
bin_n200_active3_0.5 = read.csv("med_binomialn200p500rho0.5active3.csv")[,-c(1,4)]
bin_n200_active6_0.5 = read.csv("med_binomialn200p500rho0.5active6.csv")[,-c(1,4)]
rownames1 = c("RS3","RS3+SCAD","RS3+FPCS","Lasso","Elastic","BeSS","abess","SCAD")

tableA3 = cbind(bin_n200_active3_0.5, bin_n200_active6_0.5)
rownames(tableA3) = rownames1
round(tableA3,2)  # Table A3

### Table A4 (Gaussian, rho = 0.5)
gaus_n200_active3_0.5 = read.csv("med_gaussiann200p500rho0.5active3.csv")[,-c(1,4)]
gaus_n200_active6_0.5 = read.csv("med_gaussiann200p500rho0.5active6.csv")[,-c(1,4)]
rownames1 = c("RS3","RS3+SCAD","RS3+FPCS","Lasso","Elastic","BeSS","abess","SCAD")

tableA4 = cbind(gaus_n200_active3_0.5, gaus_n200_active6_0.5)
rownames(tableA4) = rownames1
round(tableA4,2)  # Table A4