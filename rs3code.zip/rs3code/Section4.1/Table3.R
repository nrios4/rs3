# Table3.R
# Used to make Table 3 as it appears in the main text.

rm(list = ls()) # clear the environment

# change to location of directory for Section 4.1
setwd("C:/Users/nrios4/OneDrive - George Mason University - O365 Production/Desktop/rs3code/Section4.1")

meanresults = read.csv("trim32meanresults_v3.csv")
rownames1 = meanresults[,1]
meanresults = meanresults[,-1]
seresults = read.csv("trim32seresults_v3.csv")[,-1]

meanresults
seresults

table3 = matrix(nrow = 8, ncol = 4)
options(scipen = 999)
for(i in 1:8){
  for(j in 1:4){
    if(seresults[i,j] < 0.0001){
      seresults[i,j] = 0.0001
    }
    
    table3[i,j] = paste(meanresults[i,j], "(", seresults[i,j], ")", collapse = "")
  }
}

rownames(table3) = rownames1
colnames(table3) = colnames(meanresults)

table3 # This is Table 3
