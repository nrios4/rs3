# trim32.R

rm(list = ls())

library(glmnet)
library(BeSS)
library(stringr)
library(ncvreg)
library(abess) # trim32 is from here
library(future)
library(future.apply)
library(caret)


# rs3_fixed_subset_size
# helper function for rs3
# is just rs3 for a fixed subset size b
rs3_fixed_subset_size <- function(subset_size, weights, Xmat, y, family, block_size, n_split = 30, n_search = 500){
  X = Xmat
  n = nrow(X)
  p = ncol(X)
  # print(paste("Subset size",subset_size, sep = ": "))
  # print("Finding candidate subsets.")
  all_samp_preds = matrix(NA, nrow = n_search, ncol = subset_size)
  losses = numeric(n_search)
  for(s in 1:n_search){
    samp_preds = sample(1:p, subset_size, prob = weights)
    glm_m1 = glm(y ~ X[,samp_preds], family = family)
    all_samp_preds[s,] = samp_preds
    losses[s] = BIC(glm_m1)
  }
  min_ind = which.min(losses)
  smallest_loss = losses[min_ind]
  best_sol = all_samp_preds[min_ind,]
  return(list(best_sol, smallest_loss))
  
}

# Randomized Smart Subset Selection (RS3)
# Inputs:
# X (n by p matrix of predictors)
# y (vector of n resposnes)
# family ("gaussian" or "binomial")
# p_max (maximum subset size, default is 10)
# n_split: number of times the predictors are split (to search for weights), default is 100
# n_search: number of candidates for the best subset
# n_workers: number of workers for future_apply() parallel backend (default is 10)
rs3 <- function(X, y, family, block_size, p_max = 15, n_split = 30, n_search = 500,
                n_workers = 5){
  
  n = nrow(X)
  p = ncol(X)
  
  n_blocks = floor(p/block_size)
  if(block_size > n){
    stop("Block size is larger than n.")
  }
  if(length(y) != n){
    stop("Number of observations in X and y do not match.")
  }
  zscores_mat = matrix(NA, nrow = n_split, ncol = p)
  
  for(t in 1:n_split){
    pred_block_labels = as.numeric(cut(sample(1:p), n_blocks))
    # pred_block_labels = get_randomized_blocks(Xmat = X, n_blocks = n_blocks)
    tryCatch(
      {
        for(b in 1:n_blocks){
          block_inds = which(pred_block_labels == b)
          glm_tmp = glm(y ~ X[,block_inds], family = family)
          zscores_mat[t,block_inds] = abs(coef(summary(glm_tmp))[-1,3])
        }
      }, 
      error = function(e) { 
        print(e)
        zscores_mat[t,] = rep(NA, p)
      }
    )
  }
  
  print(paste0("non-NA splits: ", length(which(complete.cases(zscores_mat)))))
  
  ind.not.na <- which(complete.cases(zscores_mat))
  
  if(length(ind.not.na) == 0){
    print("No complete cases found in zscores_mat.")
    return(NA)
  }
  
  zscores = apply(zscores_mat[ind.not.na,], 2, median, na.rm=TRUE)
  w = exp(zscores^2/2)
  w = w/sum(w)
  # print("Weight estimates found.")
  losses = numeric(p_max)
  optimal_subsets = list()
  plan("multisession", workers = n_workers)
  loop.out = future_sapply(X = 1:p_max, FUN = rs3_fixed_subset_size, w = w,
                           Xmat = X, y = y, family = family, block_size = block_size, 
                           n_split = n_split, n_search = n_search, simplify = FALSE,
                           future.seed = TRUE)
  for(i in 1:p_max){
    optimal_subsets[[i]] = loop.out[[i]][[1]]
    losses[i] = loop.out[[i]][[2]]
    
  }
  min_ind = which.min(losses)
  best_subset = optimal_subsets[[min_ind]]
  return(best_subset)
}


rs3_adaptive <- function(X, y, family, block_size, n_split = 100, method = "SCAD", parallel = FALSE, n_workers = 5){
  n = nrow(X)
  p = ncol(X)
  if(p %% block_size != 0){
    stop("Number of predictors is not divisible by block_size.")
  }
  n_blocks = p/block_size
  if(block_size > n){
    stop("Block size is larger than n.")
  }
  if(length(y) != n){
    stop("Number of observations in X and y do not match.")
  }
  zscores_mat = matrix(NA, nrow = n_split, ncol = p)
  print("Estimating weights.")
  # for(t in 1:n_split){
  #   pred_block_labels = as.numeric(cut(sample(1:p), n_blocks))
  #   for(b in 1:n_blocks){
  #     block_inds = which(pred_block_labels == b)
  #     glm_tmp = glm(y ~ X[,block_inds], family = family)
  #     zscores_mat[t,block_inds] = abs(coef(summary(glm_tmp))[-1,3])
  #   }
  # }
  
  
  for(t in 1:n_split){
    pred_block_labels = as.numeric(cut(sample(1:p), n_blocks))
    # pred_block_labels = get_randomized_blocks(Xmat = X, n_blocks = n_blocks)
    tryCatch(
      {
        for(b in 1:n_blocks){
          block_inds = which(pred_block_labels == b)
          glm_tmp = glm(y ~ X[,block_inds], family = family)
          zscores_mat[t,block_inds] = abs(coef(summary(glm_tmp))[-1,3])
        }
      }, 
      error = function(e) { 
        print(e)
        zscores_mat[t,] = rep(NA, p)
      }
    )
  }
  
  print(paste0("non-NA splits: ", length(which(complete.cases(zscores_mat)))))
  print(zscores_mat)
  ind.not.na <- which(complete.cases(zscores_mat))
  
  if(length(ind.not.na) == 0){
    print("No complete cases found in zscores_mat.")
    return(NA)
  }

  zscores = apply(zscores_mat,2,median)
  w = exp(zscores^2/2)
  w = w/sum(w)
  print("found importance weights")

  p_cutoff = min(floor(1.5*n/log(n)),p)
  sorted_preds = sort(w, decreasing = TRUE, index.return = T)$ix
  selected_preds = sorted_preds[1:p_cutoff]
  print("selected predictors")
  print(selected_preds)

  X2 = X[,selected_preds]

  # now use adaptive lasso or SCAD
  if(method == "lasso"){
    cv_lasso <- cv.glmnet(x = X2, y = y, family = family)
    best_lambda <- cv_lasso$lambda.min
    lasso_fit <- glmnet(x = X2, y = y,
                        lambda = best_lambda, family = family)
    lasso_active_set <- selected_preds[which(abs(lasso_fit$beta) > 0)]
    return(lasso_active_set)
  }
  if(method == "SCAD"){
    out_cv_ncvreg <- cv.ncvreg(X = X2, y = y, family = family, penalty = "SCAD")
    ncvreg_beta <- coef(out_cv_ncvreg, s = "lambda.min")[-1]
    ncvreg_active_set <- selected_preds[which(abs(ncvreg_beta) > 0)]
    return(ncvreg_active_set)
  }
  if(method == "FPC"){
    n_subsample <- 100
    # proportion of data to remove
    if(family == "gaussian"){
      prop <- 0.05
    }
    if(family == "binomial"){
      prop <- 0.05
    }
    p_selected <- length(selected_preds)
    # positive <- rep(0, p_selected)
    # negative <- rep(0, p_selected)
    if(parallel){
      plan("multisession", workers = n_workers)
    } else{
      plan("sequential")
    }
    fpc_helper <- function(i,y, X2, family,prop,n,p_selected){
      positive <- rep(0, p_selected)
      negative <- rep(0, p_selected)
      remove <- sample(c(1:n), prop * n)
      Y.sample <- y[-remove]
      X.sample <- X2[-remove,]
      out_cv_ncvreg <- cv.ncvreg(X = X.sample, y = Y.sample, family = family, penalty = "SCAD")
      beta_best <- as.vector(coef(out_cv_ncvreg, s = "lambda.min")[-1])
      positive <- positive + (beta_best >= 0)
      negative <- negative + (beta_best <= 0)
      return(rbind(positive,negative))
    }
    loop.out = future_sapply(X = 1:n_subsample, FUN = fpc_helper, y=y,X2=X2,family=family,
                             prop=prop,n=n,p_selected = p_selected,
                             simplify = FALSE,future.seed = TRUE)
    positive <- rep(0, p_selected)
    negative <- rep(0, p_selected)
    for(i in 1:n_subsample){
      positive <- positive + loop.out[[i]][1,]
      negative <- negative + loop.out[[i]][2,]
    }
    index <- selected_preds[which(as.vector(positive / negative) %in% c(Inf, 0))]
    print(index)
    if(length(index) == 1){
      return(index)
    }
    if(length(index) == 0){
      return(NULL)
    }
    # for (i in 1:n_subsample) {
    #   remove <- sample(c(1:n), prop * n)
    #   Y.sample <- y[-remove]
    #   X.sample <- X2[-remove,]
    #
    #   cv_lasso <- cv.glmnet(x = X.sample, y = Y.sample, family = family, alpha = 1, nfolds = 10)
    #   best_lambda <- cv_lasso$lambda.min
    #   lasso_fit <- glmnet(x = X.sample, y = Y.sample, lambda = best_lambda, family = family)
    #   beta_best <- as.vector(lasso_fit$beta)
    #
    #   positive <- positive + (beta_best >= 0)
    #   negative <- negative + (beta_best <= 0)
    # }
    # index <- selected_preds[which(as.vector(positive / negative) %in% c(Inf, 0))]
    out_cv_ncvreg <- cv.ncvreg(X = X[,index], y = y, family = family, penalty = "SCAD")
    ncvreg_beta <- coef(out_cv_ncvreg, s = "lambda.min")[-1]
    ncvreg_active_set <- index[which(abs(ncvreg_beta) > 0)]
    return(ncvreg_active_set)
  }
}


data("trim32")
sum(is.na(trim32)) # no missing values
dim(trim32)
# y is response

# rename other columns to x1, ..., x500
colnames(trim32) <- c("y",paste("x",1:500,sep = ""))
X = as.matrix(trim32[,-1])
y = trim32$y

set.seed(123)
n_check = 100
rs3_results <- matrix(NA, nrow = n_check, ncol = 4)
rs3scad_results <- matrix(NA, nrow = n_check, ncol = 4)
rs3fpc_results <- matrix(NA, nrow = n_check, ncol = 4)
lasso_results <- matrix(NA, nrow = n_check, ncol = 4)
elastic_results <- matrix(NA, nrow = n_check, ncol = 4)
bess_results <- matrix(NA, nrow = n_check, ncol = 4)
abess_results <- matrix(NA, nrow = n_check, ncol = 4)
ncvreg_results <- matrix(NA, nrow = n_check, ncol = 4)

for(iter in 1:n_check){
  train_inds = sample(1:nrow(X),floor(0.8*nrow(X)))
  X.train = X[train_inds,]
  y.train = y[train_inds]
  y.test = y[-train_inds]
  
  # try RS3 (rs3)
  rs3_start <- Sys.time()
  out_rs3 = rs3(X=X.train,y=y.train,family = "gaussian",block_size = 25, n_search = 100, n_workers = 5)
  rs3_end <- Sys.time()
  rs3_cpu <- as.numeric(rs3_end - rs3_start, units = "secs")
  
  formula_rs3 = paste("y ~", paste(colnames(trim32[-1])[out_rs3],collapse = "+"), sep = " ")
  rs3_model <- glm(formula_rs3, family = "gaussian", data = trim32[train_inds,])
  rs3_yhats <- predict(rs3_model, trim32[-train_inds,])
  rs3_MSPE <- mean((y.test - rs3_yhats)^2)
  
  
  # try RS3 + SCAD (rs3scad)
  rs3scad_start <- Sys.time()
  out_rs3scad = rs3_adaptive(X=X.train,y=y.train,family = "gaussian",block_size = 25, method = "SCAD")
  rs3scad_end <- Sys.time()
  rs3scad_cpu <- as.numeric(rs3scad_end - rs3scad_start, units = "secs")
  
  formula_rs3scad = paste("y ~", paste(colnames(trim32[-1])[out_rs3scad],collapse = "+"), sep = " ")
  rs3scad_model <- glm(formula_rs3scad, family = "gaussian", data = trim32[train_inds,])
  rs3scad_yhats <- predict(rs3scad_model, trim32[-train_inds,])
  rs3scad_MSPE <- mean((y.test - rs3scad_yhats)^2)
  
  # # try RS3 + FPC (rs3fpc)
  rs3fpc_start <- Sys.time()
  out_rs3fpc = rs3_adaptive(X=X.train,y=y.train,family = "gaussian",block_size = 25, method = "FPC", n_workers = 5)
  rs3fpc_end <- Sys.time()
  rs3fpc_cpu <- as.numeric(rs3fpc_end - rs3fpc_start, units = "secs")

  if(length(out_rs3fpc) == 0){
    formula_rs3fpc = "y ~ 1"
  } else{
    formula_rs3fpc = paste("y ~", paste(colnames(trim32[-1])[out_rs3fpc],collapse = "+"), sep = " ")
  }
  rs3fpc_model <- glm(formula_rs3fpc, family = "gaussian", data = trim32[train_inds,])
  rs3fpc_yhats <- predict(rs3fpc_model, trim32[-train_inds,])
  rs3fpc_MSPE <- mean((y.test - rs3fpc_yhats)^2)
  
  
  
  # try lasso (glmnet)
  lasso_start_time <- Sys.time()
  cv_lasso <- cv.glmnet(x = X.train, y = y.train, family = "gaussian")
  best_lambda <- cv_lasso$lambda.min
  lasso_fit <- glmnet(x = X.train, y = y.train,
                      lambda = best_lambda, family = "gaussian")
  lasso_active_set <- which(abs(lasso_fit$beta) > 0)
  lasso_end_time <- Sys.time()
  lasso_cpu <- as.numeric(lasso_end_time - lasso_start_time, units = "secs")
  
  formula_lasso = paste("y ~", paste(colnames(trim32[-1])[lasso_active_set],collapse = "+"), sep = " ")
  lasso_model <- glm(formula_lasso, family = "gaussian", data = trim32[train_inds,])
  lasso_yhats <- predict(lasso_model,  trim32[-train_inds,], type = "response")
  lasso_MSPE <- mean((y.test - lasso_yhats)^2)
  
  # try elasticnet
  elastic_start_time <- Sys.time()
  cv5 = trainControl(method = "cv", number = 5)
  cv_elasticnet <- train(x = X.train, y = y.train, method = "glmnet",
                         family = "gaussian", trControl = cv5)
  best_alpha = as.numeric(cv_elasticnet$bestTune[1])
  best_lambda = as.numeric(cv_elasticnet$bestTune[2])
  elasticnet_fit = glmnet(x = X.train, y = y.train, family = "gaussian", alpha = best_alpha, 
                          lambda = best_lambda)
  elastic_active_set <- which(abs(elasticnet_fit$beta) > 0)
  elastic_end_time <- Sys.time()
  elastic_cpu <- as.numeric(elastic_end_time - elastic_start_time, units = "secs")
  
  formula_elastic = paste("y ~", paste(colnames(trim32[-1])[elastic_active_set],collapse = "+"), sep = " ")
  elastic_model <- glm(formula_elastic, family = "gaussian", data = trim32[train_inds,])
  elastic_yhats <- predict(elastic_model,  trim32[-train_inds,], type = "response")
  elastic_MSPE <- mean((y.test - elastic_yhats)^2)
  
  # try BeSS
  bess_start_time <- Sys.time()
  out_bess <- bess(x = X.train, y = y.train, family = "gaussian")
  bess_active_set <- as.numeric(unlist(str_extract_all(names(coef(out_bess$bestmodel)[-1]), "[0-9]+")))
  bess_end_time <- Sys.time()
  bess_cpu <- as.numeric(bess_end_time - bess_start_time, units = "secs")
  
  formula_bess = paste("y ~ ", paste(colnames(trim32[-1])[bess_active_set],collapse = "+"), sep = " ")
  if(length(bess_active_set) == 0){
    formula_bess = "y ~ 1"
  }
  bess_model <- glm(formula_bess, family = "gaussian", data = trim32[train_inds,])
  bess_yhats <- predict(bess_model,  trim32[-train_inds,], type = "response")
  bess_MSPE <- mean((y.test - bess_yhats)^2)
  
  # check abess ( Zhu J, Wang X, Hu L, Huang J, Jiang K, Zhang Y, Lin S, Zhu J (2022). 'abess: A Fast Best Subset Selection Library in Python and R.' Journal of Machine Learning Research, 23(202), 1-7. https://www.jmlr.org/papers/v23/21-1060.html.)
  abess_start_time <- Sys.time()
  out_abess <- abess(x = X.train, y = y.train, family = "gaussian")
  abess_beta <- extract(out_abess, out_abess$best.size)$beta
  abess_active_set <- which(abess_beta != 0)
  abess_end_time <- Sys.time()
  abess_cpu <- as.numeric(abess_end_time - abess_start_time , units = "secs")
  
  formula_abess = paste("y ~ ", paste(colnames(trim32[-1])[abess_active_set],collapse = "+"), sep = " ")
  if(length(abess_active_set) == 0){
    formula_abess = "y ~ 1"
  }
  abess_model <- glm(formula_abess, family = "gaussian", data = trim32[train_inds,])
  abess_yhats <- predict(abess_model,  trim32[-train_inds,], type = "response")
  abess_MSPE <- mean((y.test - abess_yhats)^2)
  
  # check SCAD (https://pmc.ncbi.nlm.nih.gov/articles/PMC3212875/pdf/nihms332857.pdf)
  # doesn't work for saturated model, so first use marginal filtering
  ncvreg_start_time <- Sys.time()
  n = nrow(trim32)
  p = ncol(trim32)-1
  abs_zscores = numeric(p)
  for(j in 1:p){
    tmp_df = data.frame(y = y.train,x = X.train[,j])
    marginal_glm = glm(y ~ x, data = tmp_df, family = "gaussian")
    abs_zscores[j] = abs(coef(summary(marginal_glm))[-1,3])
  }
  # now choose the top n/2 scores
  sorted_inds = sort(abs_zscores, index.return = TRUE, decreasing = TRUE)$ix
  top_preds = sorted_inds[1:floor(0.5*n)]
  X2 = X.train[,top_preds]
  out_cv_ncvreg <- cv.ncvreg(X = X2, y = y.train, family = "gaussian", penalty = "SCAD")
  ncvreg_beta <- coef(out_cv_ncvreg, s = "lambda.min")[-1]
  ncvreg_active_set <- top_preds[which(abs(ncvreg_beta) > 0)]
  ncvreg_end_time <- Sys.time()
  ncvreg_cpu <- as.numeric(ncvreg_end_time - ncvreg_start_time, units = "secs")
  
  formula_ncvreg = paste("y ~ ", paste(colnames(trim32[-1])[ncvreg_active_set],collapse = "+"), sep = " ")
  if(length(ncvreg_active_set) == 0){
    formula_ncvreg = "y ~ 1"
  }
  ncvreg_model <- glm(formula_ncvreg, family = "gaussian", data = trim32[train_inds,])
  ncvreg_yhats <- predict(ncvreg_model,  trim32[-train_inds,], type = "response")
  ncvreg_MSPE <- mean((y.test - ncvreg_yhats)^2)
  
  rs3_results[iter,] <- c(rs3_MSPE, AIC(rs3_model),BIC(rs3_model), rs3_cpu)
  rs3scad_results[iter,] <- c(rs3scad_MSPE, AIC(rs3scad_model), BIC(rs3scad_model), rs3scad_cpu)
  rs3fpc_results[iter,] <- c(rs3fpc_MSPE, AIC(rs3fpc_model), BIC(rs3fpc_model), rs3fpc_cpu)
  lasso_results[iter,] <- c(lasso_MSPE, AIC(lasso_model), BIC(lasso_model), lasso_cpu)
  elastic_results[iter,] <- c(elastic_MSPE, AIC(elastic_model), BIC(elastic_model), elastic_cpu)
  bess_results[iter,] <- c(bess_MSPE, AIC(bess_model), BIC(bess_model), bess_cpu)
  abess_results[iter,] <- c(abess_MSPE, AIC(abess_model), BIC(abess_model), abess_cpu)
  ncvreg_results[iter,] <- c(ncvreg_MSPE, AIC(ncvreg_model), BIC(ncvreg_model), ncvreg_cpu)
}

res_table <- round(rbind(colMeans(rs3_results),
                         colMeans(rs3scad_results),
                         colMeans(rs3fpc_results),
                         colMeans(lasso_results),
                         colMeans(elastic_results),
                         colMeans(bess_results),
                         colMeans(abess_results),
                         colMeans(ncvreg_results)),4)

rownames(res_table) <- c("RS3","RS3+SCAD","RS3+FPC","Lasso", "ElasticNet", "BeSS", "abess", "SCAD")
colnames(res_table) <- c("MSPE", "AIC", "BIC", "CPU")
res_table

# find standard errors for each
se_res_table <- round(rbind( apply(rs3_results,2,function(x) sd(x)/sqrt(n_check)),
                             apply(rs3scad_results,2,function(x) sd(x)/sqrt(n_check)),
                             apply(rs3fpc_results,2,function(x) sd(x)/sqrt(n_check)),
                             apply(lasso_results,2,function(x) sd(x)/sqrt(n_check)),
                             apply(elastic_results,2,function(x) sd(x)/sqrt(n_check)),
                             apply(bess_results,2,function(x) sd(x)/sqrt(n_check)),
                             apply(abess_results,2,function(x) sd(x)/sqrt(n_check)),
                             apply(ncvreg_results,2,function(x) sd(x)/sqrt(n_check))) , 4)
rownames(se_res_table) <- c("RS3","RS3+SCAD","RS3+FPC", "Lasso", "ElasticNet", "BeSS", "abess", "SCAD")
colnames(se_res_table) <- c("MSPE", "AIC", "BIC", "CPU")
se_res_table # standard errors

# setwd("~/GMU/Papers in Progress/SubsetSelection/rs3code") 
# write.csv(res_table,"trim32meanresults_v3.csv")
# write.csv(se_res_table,"trim32seresults_v3.csv")
