rm(list=ls())

library(glmnet)
library(BeSS)
library(stringr)
library(ncvreg)
library(abess)
library(future)
library(future.apply)
library(caret)

# rs3_fixed_subset_size
# helper function for rs3
# is just rs3 for a fixed subset size b
rs3_fixed_subset_size <- function(subset_size, weights, Xmat, y, family, block_size, n_split = 30, n_search = 500){
  X = Xmat
  n = nrow(X)
  p = ncol(X)
  # print(paste("Subset size",subset_size, sep = ": "))
  # print("Finding candidate subsets.")
  all_samp_preds = matrix(NA, nrow = n_search, ncol = subset_size)
  losses = numeric(n_search)
  for(s in 1:n_search){
    samp_preds = sample(1:p, subset_size, prob = weights)
    glm_m1 = glm(y ~ X[,samp_preds], family = family)
    all_samp_preds[s,] = samp_preds
    losses[s] = BIC(glm_m1)
  }
  min_ind = which.min(losses)
  smallest_loss = losses[min_ind]
  best_sol = all_samp_preds[min_ind,]
  return(list(best_sol, smallest_loss))
  
}

# Randomized Smart Subset Selection (RS3)
# Inputs:
# X (n by p matrix of predictors)
# y (vector of n resposnes)
# family ("gaussian" or "binomial")
# p_max (maximum subset size, default is 10)
# n_split: number of times the predictors are split (to search for weights), default is 100
# n_search: number of candidates for the best subset
# n_workers: number of workers for future_apply() parallel backend (default is 10)
rs3 <- function(X, y, family, block_size, p_max = 15, n_split = 30, n_search = 500,
                n_workers = 5){
  
  n = nrow(X)
  p = ncol(X)
  
  n_blocks = floor(p/block_size)
  if(block_size > n){
    stop("Block size is larger than n.")
  }
  if(length(y) != n){
    stop("Number of observations in X and y do not match.")
  }
  zscores_mat = matrix(NA, nrow = n_split, ncol = p)
  
  for(t in 1:n_split){
    pred_block_labels = as.numeric(cut(sample(1:p), n_blocks))
    # pred_block_labels = get_randomized_blocks(Xmat = X, n_blocks = n_blocks)
    tryCatch(
      {
        for(b in 1:n_blocks){
          block_inds = which(pred_block_labels == b)
          glm_tmp = glm(y ~ X[,block_inds], family = family)
          zscores_mat[t,block_inds] = abs(coef(summary(glm_tmp))[-1,3])
        }
      }, 
      error = function(e) { 
        print(e)
        zscores_mat[t,] = rep(NA, p)
      }
    )
  }
  
  print(paste0("non-NA splits: ", length(which(complete.cases(zscores_mat)))))
  
  ind.not.na <- which(complete.cases(zscores_mat))
  
  if(length(ind.not.na) == 0){
    print("No complete cases found in zscores_mat.")
    return(NA)
  }
  
  zscores = apply(zscores_mat[ind.not.na,], 2, median, na.rm=TRUE)
  w = exp(zscores^2/2)
  w = w/sum(w)
  # print("Weight estimates found.")
  losses = numeric(p_max)
  optimal_subsets = list()
  plan("multisession", workers = n_workers)
  loop.out = future_sapply(X = 1:p_max, FUN = rs3_fixed_subset_size, w = w,
                           Xmat = X, y = y, family = family, block_size = block_size, 
                           n_split = n_split, n_search = n_search, simplify = FALSE,
                           future.seed = TRUE)
  for(i in 1:p_max){
    optimal_subsets[[i]] = loop.out[[i]][[1]]
    losses[i] = loop.out[[i]][[2]]
    
  }
  min_ind = which.min(losses)
  best_subset = optimal_subsets[[min_ind]]
  return(best_subset)
}



# Randomized Smart Subset Selection (RS3) Adaptive
# Inputs:
# X (n by p matrix of predictors)
# y (vector of n resposnes)
# family ("gaussian" or "binomial")
# n_split: number of times the predictors are split (to search for weights), default is 100
# method = "lasso" or "SCAD" or "FPC" (default is SCAD)
rs3_adaptive <- function(X, y, family, block_size, n_split = 100, method = "SCAD"){
  n = nrow(X)
  p = ncol(X)
  
  n_blocks = floor(p/block_size)
  if(block_size > n){
    stop("Block size is larger than n.")
  }
  if(length(y) != n){
    stop("Number of observations in X and y do not match.")
  }
  zscores_mat = matrix(NA, nrow = n_split, ncol = p)
  
  for(t in 1:n_split){
    pred_block_labels = as.numeric(cut(sample(1:p), n_blocks))
    # pred_block_labels = get_randomized_blocks(Xmat = X, n_blocks = n_blocks)
    tryCatch(
      {
        for(b in 1:n_blocks){
          block_inds = which(pred_block_labels == b)
          glm_tmp = glm(y ~ X[,block_inds], family = family)
          zscores_mat[t,block_inds] = abs(coef(summary(glm_tmp))[-1,3])
        }
      }, 
      error = function(e) { 
        print(e)
        zscores_mat[t,] = rep(NA, p)
      }
    )
  }
  
  print(paste0("non-NA splits: ", length(which(complete.cases(zscores_mat)))))
  
  ind.not.na <- which(complete.cases(zscores_mat))
  
  if(length(ind.not.na) == 0){
    print("No complete cases found in zscores_mat.")
    return(NA)
  }
  
  zscores = apply(zscores_mat[ind.not.na,], 2, median, na.rm=TRUE)
  # zscores = apply(zscores_mat, 2, function(x) quantile(x,0.9))
  w = exp(zscores^2/2)
  w = w/sum(w)
  print("found importance weights")
  
  p_cutoff = floor(1.5*n/log(n))
  sorted_preds = sort(w, decreasing = TRUE, index.return = T)$ix
  selected_preds = sorted_preds[1:p_cutoff]
  X2 = X[,selected_preds]
  
  # now use lasso or SCAD or FPC on the selected predictors
  if(method == "lasso"){
    cv_lasso <- cv.glmnet(x = X2, y = y, family = family)
    best_lambda <- cv_lasso$lambda.min
    lasso_fit <- glmnet(x = X2, y = y,
                        lambda = best_lambda, family = family)
    lasso_active_set <- selected_preds[which(abs(lasso_fit$beta) > 0)]
    return(lasso_active_set)
  } 
  if(method == "SCAD"){
    out_cv_ncvreg <- cv.ncvreg(X = X2, y = y, family = family, penalty = "SCAD")
    ncvreg_beta <- coef(out_cv_ncvreg, s = "lambda.min")[-1]
    ncvreg_active_set <- selected_preds[which(abs(ncvreg_beta) > 0)]
    return(ncvreg_active_set)
  }
  if(method == "FPC"){
    n_subsample <- 100
    
    # proportion of data to remove
    if(family == "gaussian"){
      prop <- 0.3 
    }
    if(family == "binomial"){
      prop <- 0.05
    }
    
    p_selected <- length(selected_preds)
    positive <- rep(0, p_selected)
    negative <- rep(0, p_selected)
    
    for (i in 1:n_subsample) {
      remove <- sample(c(1:n), prop * n)
      Y.sample <- y[-remove]
      X.sample <- X2[-remove,]
      
      out_cv_ncvreg <- cv.ncvreg(X = X.sample, y = Y.sample, family = family, penalty = "SCAD")
      beta_best <- as.vector(coef(out_cv_ncvreg, s = "lambda.min")[-1])
      
      positive <- positive + (beta_best >= 0)
      negative <- negative + (beta_best <= 0)
    }
    index <- selected_preds[which(as.vector(positive / negative) %in% c(Inf, 0))]
    print(index)
    
    if(length(index) == 0){
      return(NA)
    }
    out_cv_ncvreg <- cv.ncvreg(X = X[,index,drop=FALSE], y = y, family = family, penalty = "SCAD")
    ncvreg_beta <- coef(out_cv_ncvreg, s = "lambda.min")[-1]
    ncvreg_active_set <- index[which(abs(ncvreg_beta) > 0)]
    return(ncvreg_active_set)
  }
}

# GSE217352
family <- "binomial"
data <- read.table("GSE217352_RNASEQ-FPKM.txt", header = TRUE, sep = "\t")
# remove the first 28 rows of metadata
data <- data[-c(1:28), ]
# remove the columns with column name including "PostSurgery"
data <- data[, !grepl("PostSurgery", colnames(data))]
# remove the columns with column name including "NL"
data <- data[, !grepl("NL", colnames(data))]

# # Read data metadata to get information of duplicated samples
# lines <- readLines("GSE217352_series_matrix.txt")
# # Extract lines starting with '!Sample_'
# sample_lines <- grep("^!Sample_", lines, value = TRUE)
# # Convert to data frame
# library(tidyr)
# library(dplyr)
# # Parse and reshape
# meta_df <- do.call(rbind, lapply(sample_lines, function(line) {
#   parts <- strsplit(line, "\t")[[1]]
#   name <- gsub("^!Sample_", "", parts[1])
#   values <- parts[-1]
#   data.frame(variable = name, t(values), stringsAsFactors = FALSE)
# }))  # X96 is Patient232763_CD_Surgery_PBT_Duplicate (corr=0.970979); X80 is Patient238832_CD_Surgery_PBT_Duplicate (corr=0.7705482)
# remove the columns with column name including "Duplicate"
data <- data[, !grepl("Duplicate", colnames(data))]

rownames(data) <- data[,1]
data <- data[ , -1]
dim(data)

# Remove genes with more than 80% zero counts samples
length(which(rowSums(data==0)<ncol(data)*.8))
data=data[which(rowSums(data==0)<ncol(data)*.8),]
dim(data)

# Only keep the genes whose variance is within the top 10 percentile
length(which(apply(data,1,var)>quantile(apply(data,1,var),0.95)))
data=data[which(apply(data,1,var)>quantile(apply(data,1,var),0.95)),]
dim(data)

data <- t(data)
# n=dim(data)[1]
p=dim(data)[2]

# normalization
data.norm=log(data+1)
for(i in 1:p){
  data.norm[,i]=data.norm[,i]-mean(data.norm[,i])
  data.norm[,i]=data.norm[,i]/sd(data.norm[,i])
}
dat <- as.data.frame(data.norm)

# response variable
# PBT (CD-PBT: peripheral blood T cell): 1
# LPT (CD-PBmu: lamina propria mucosa-derived T cell): 0
y <- ifelse(grepl("PBT", rownames(dat)), 1, 0) 

dat <- as.data.frame(cbind(y, dat))
X <- as.matrix(dat[,-1])
dim(X)

##### split data into train and test sets #####
# library(xgboost)
library(Matrix)

# function for calculating accuracy
accuracy <- function(X.train, y.train, X.test, y.test, active_set) {
  # # classification with xgboost
  # dtrain <- xgb.DMatrix(data = as.matrix(X.train[,active_set]), label = y.train)
  # params <- list(
  #   objective = "binary:logistic",  # binary classification
  #   eval_metric = "logloss",        # evaluation metric
  #   max_depth = 4,                  # depth of tree
  #   eta = 0.1,                      # learning rate
  #   subsample = 0.8,                # row sampling
  #   colsample_bytree = 0.8          # feature sampling
  # )
  # xgb_model <- xgb.train(
  #   params = params,
  #   data = dtrain,
  #   nrounds = 100,
  #   verbose = 0
  # )
  # pred_probs <- predict(xgb_model, as.matrix(X.test[,active_set]))
  # pred_labels <- ifelse(pred_probs > 0.5, 1, 0)
  # return(mean(pred_labels == y.test))  # accuracy
  
  # classification with glm
  model <- glm(y ~ ., data = data.frame(y = y.train, X = X.train[,active_set]), family = family)
  predicted_probs <- predict(model, data.frame(y = y.test, X = X.test[,active_set]), type = "response")
  predictions <- ifelse(predicted_probs > 0.5, 1, 0)
  return(mean(predictions == y.test))
}

#### parallel computing setup ####
library(doParallel)
library(foreach)
unregister_dopar <- function() {
  env <- foreach:::.foreachGlobals
  rm(list=ls(name=env), pos=env)
}
retry <- function(expr, isError=function(x) "try-error" %in% class(x), maxErrors = 15, sleep = 5) {
  attempts = 0
  retval = try(eval(expr))
  while (isError(retval)) {
    attempts = attempts + 1
    if (attempts >= maxErrors) {
      msg = sprintf("retry: too many retries [[%s]]", capture.output(str(retval)))
      flog.fatal(msg)
      stop(msg)
    } else {
      msg = sprintf("retry: error in attempt %i/%i [[%s]]", attempts, maxErrors, 
                    capture.output(str(retval)))
      flog.error(msg)
      warning(msg)
    }
    if (sleep > 0) Sys.sleep(sleep)
    retval = try(eval(expr))
  }
  return(retval)
}

closeAllConnections()
unregister_dopar()
n.cores <- parallel::detectCores()
retry({
  my.cluster <- parallel::makeCluster(n.cores, type = "FORK", outfile="")
  # my.cluster <- parallel::makeCluster(n.cores, type = "PSOCK", outfile="")
  doParallel::registerDoParallel(cl = my.cluster)
})
foreach::getDoParRegistered()
foreach::getDoParWorkers()


###### run simulation ######
n.rep <- 100

res <- foreach(i = 1:n.rep, .packages = c("glmnet", "BeSS", "ncvreg", "abess", "xgboost")) %dopar% {
  set.seed(i)
  n.try <- 0
  while(TRUE){
    n.try <- n.try + 1
    try.res <- tryCatch(
      {
        train_id = sample(1:nrow(X)/2,floor(0.8*nrow(X))) # 80% of the pairs for training
        train_inds <- c(2*train_id, 2*train_id - 1)
        X.train = X[train_inds,]
        y.train = y[train_inds]
        y.test = y[-train_inds]
        X.test <- X[-train_inds,]
        
        # try RS3
        rs3_start <- Sys.time()
        rs3_active_set = rs3(X=X.train, y=y.train, n_split = 100, family = family, block_size = 30)
        # colnames(X)[rs3_active_set]
        rs3_end <- Sys.time()
        rs3_cup <- as.numeric(rs3_end - rs3_start, units = "secs")
        if (is.na(rs3_active_set)) {
          rs3_accuracy <- NA
        } else{
          rs3_accuracy <- accuracy(X.train, y.train, X.test, y.test, rs3_active_set)
        }
        
        # try RS3+SCAD
        rs3_scad_start <- Sys.time()
        rs3_scad_active_set = rs3_adaptive(X=X.train, y=y.train, n_split = 100, family = family, block_size = 30)
        # colnames(X)[rs3_active_set]
        rs3_scad_end <- Sys.time()
        rs3_scad_cup <- as.numeric(rs3_scad_end - rs3_scad_start, units = "secs")
        if (is.na(rs3_scad_active_set)) {
          rs3_scad_accuracy <- NA
        } else{
          rs3_scad_accuracy <- accuracy(X.train, y.train, X.test, y.test, rs3_scad_active_set)
        }
        
        # try RS3+FPC
        fpc_start <- Sys.time()
        fpc_active_set = rs3_adaptive(X=X.train, y=y.train, n_split = 100, family = family, block_size = 30, method = "FPC")
        # colnames(X)[fpc_active_set]
        fpc_end <- Sys.time()
        fpc_cup <- as.numeric(fpc_end - fpc_start, units = "secs")
        if (is.na(fpc_active_set)) {
          fpc_accuracy <- NA
        } else{
          fpc_accuracy <- accuracy(X.train, y.train, X.test, y.test, fpc_active_set)
        }
        
        # try BeSS
        bess_start_time <- Sys.time()
        out_bess <- bess(x = X.train, y = y.train, family = family)
        bess_active_set <- which(colnames(X.train) %in% gsub('xbest', '', names(coef(out_bess$bestmodel)[-1])))
        # colnames(X)[bess_active_set]
        bess_end_time <- Sys.time()
        bess_cpu <- as.numeric(bess_end_time - bess_start_time, units = "secs")
        bess_accuracy <- accuracy(X.train, y.train, X.test, y.test, bess_active_set)
        
        # try abess
        abess_start_time <- Sys.time()
        out_abess <- abess(x = X.train, y = y.train, family = family)
        abess_beta <- out_abess$beta[, out_abess$best.size+1]
        abess_active_set <- which(abess_beta != 0)
        # colnames(X)[abess_active_set]
        abess_end_time <- Sys.time()
        abess_cpu <- as.numeric(abess_end_time - abess_start_time, units = "secs")
        abess_accuracy <- accuracy(X.train, y.train, X.test, y.test, abess_active_set)
        
        # try lasso (glmnet)
        lasso_start_time <- Sys.time()
        cv_lasso <- cv.glmnet(x = X.train, y = y.train, family = family)
        best_lambda <- cv_lasso$lambda.min
        lasso_fit <- glmnet(x = X.train, y = y.train,
                            lambda = best_lambda, family = family)
        lasso_active_set <- which(abs(lasso_fit$beta) > 0)
        # colnames(X)[lasso_active_set]
        lasso_end_time <- Sys.time()
        lasso_cpu <- as.numeric(lasso_end_time - lasso_start_time, units = "secs")
        lasso_accuracy <- accuracy(X.train, y.train, X.test, y.test, lasso_active_set)
        
        # try ncvreg
        ncvreg_start_time <- Sys.time()
        out_cv_ncvreg <- cv.ncvreg(X = X.train, y = y.train, family = family, penalty = "SCAD")
        ncvreg_beta <- coef(out_cv_ncvreg, s = "lambda.min")[-1]
        ncvreg_active_set <- which(abs(ncvreg_beta) > 0)
        # colnames(X)[ncvreg_active_set]
        ncvreg_end_time <- Sys.time()
        ncvreg_cpu <- as.numeric(ncvreg_end_time - ncvreg_start_time, units = "secs")
        ncvreg_accuracy <- accuracy(X.train, y.train, X.test, y.test, ncvreg_active_set)
        
        return(list(
          rs3_active_set = rs3_active_set,
          rs3_cpu = rs3_cup,
          rs3_accuracy = rs3_accuracy,
          
          rs3_scad_active_set = rs3_scad_active_set,
          rs3_scad_cpu = rs3_scad_cup,
          rs3_scad_accuracy = rs3_scad_accuracy,
          
          fpc_active_set = fpc_active_set,
          fpc_cpu = fpc_cup,
          fpc_accuracy = fpc_accuracy,
          
          bess_active_set = bess_active_set,
          bess_cpu = bess_cpu,
          bess_accuracy = bess_accuracy,
          
          abess_active_set = abess_active_set,
          abess_cpu = abess_cpu,
          abess_accuracy = abess_accuracy,
          
          lasso_active_set = lasso_active_set,
          lasso_cpu = lasso_cpu,
          lasso_accuracy = lasso_accuracy,
          
          ncvreg_active_set = ncvreg_active_set,
          ncvreg_cpu = ncvreg_cpu,
          ncvreg_accuracy = ncvreg_accuracy
        ))
      },
      error = function(e) { 
        print(e)
        'try-error'
      }
    )
    if(length(try.res) > 1) break
    if(n.try > 1) {
      print("Tried many times; try to resubmit the job.")
      return(NULL)
    }
  }
  return(try.res)
}



# calculate average cup and accuracy with standard deviation
results <- list()
for (method in c("rs3", "rs3_scad", "fpc", "bess", "abess", "ncvreg", "lasso")) {
  active_set <- lapply(res, function(x) x[[paste0(method, "_active_set")]])
  # remove NA values
  active_set <- active_set[!unlist(lapply(active_set, is.null))]
  # size of each active set
  active_set_size <- sapply(active_set, length)
  
  active_set_all <- unique(unlist(active_set))
  # select genes that are selected in at least 95% of the runs
  active_set_95 <- active_set_all[which(sapply(active_set_all, 
                                               function(x) {
                                                 count <- 0
                                                 for (i in 1:length(active_set)) 
                                                   if (x %in% active_set[[i]]) count <- count + 1
                                                 return(count)
                                               }) >= n.rep * .95)]
  
  cpu <- sapply(res, function(x) x[[paste0(method, "_cpu")]])
  accuracy <- sapply(res, function(x) x[[paste0(method, "_accuracy")]])
  
  results[[method]] <- list(
    avg_active_set_size = mean(active_set_size),
    sd_active_set_size = sd(active_set_size) / sqrt(n.rep),
    active_set_95 = active_set_95,
    avg_cpu = mean(cpu),
    sd_cpu = sd(cpu) / sqrt(n.rep),
    avg_accuracy = mean(accuracy, na.rm = TRUE),
    sd_accuracy = sd(accuracy, na.rm = TRUE) / sqrt(n.rep)
  )
}

# print results in a table
results_df <- data.frame(
  Avg_Active_Set_Size = sapply(results, function(x) x$avg_active_set_size),
  SD_Active_Set_Size = sapply(results, function(x) x$sd_active_set_size),
  Selected_Predictors = sapply(results, function(x) paste(colnames(X)[x$active_set_95], collapse = ", ")),
  Avg_CPU = sapply(results, function(x) x$avg_cpu),
  SD_CPU = sapply(results, function(x) x$sd_cpu),
  Avg_Accuracy = sapply(results, function(x) x$avg_accuracy),
  SD_Accuracy = sapply(results, function(x) x$sd_accuracy)
)
print(results_df)

# stop the cluster
closeAllConnections()



