# Table5.R
# Used to make Table 5 as it appears in the main text.

rm(list = ls()) # clear the environment

# change to location of directory for Section 4.1
setwd("~/GMU/Papers in Progress/SubsetSelection/rs3code_r1/Section 4.1")

meanresults = read.csv("trim32meanresults_v3.csv")
rownames1 = meanresults[,1]
meanresults = meanresults[,-1]
seresults = read.csv("trim32seresults_v3.csv")[,-1]

meanresults
seresults

table5 = matrix(nrow = 8, ncol = 4)
options(scipen = 999)
for(i in 1:8){
  for(j in 1:4){
    if(seresults[i,j] < 0.0001){
      seresults[i,j] = 0.0001
    }
    
    table5[i,j] = paste(meanresults[i,j], "(", seresults[i,j], ")", collapse = "")
  }
}

rownames(table5) = rownames1
colnames(table5) = colnames(meanresults)

table5 # This is Table 5
