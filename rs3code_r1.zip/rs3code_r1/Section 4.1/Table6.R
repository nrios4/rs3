
setwd("~/GMU/Papers in Progress/SubsetSelection/rs3code_r1/Section 4.1") 
rs3_activeset_list = readRDS("trim32rs3list.csv")
rs3scad_activeset_list = readRDS("trim32rs3scadlist.csv")
rs3fpc_activeset_list = readRDS("trim32rs3fpclist.csv")
lasso_activeset_list = readRDS("trim32lassolist.csv")
bess_activeset_list = readRDS("trim32besslist.csv")
abess_activeset_list = readRDS("trim32abesslist.csv")
ncvreg_activeset_list = readRDS("trim32ncvreglist.csv")

n_check = 100

table6 = matrix(nrow = 7, ncol = 3)
options(scipen = 999)

######## Values needed for Table 6 ###########
# report predictors that each method detects 80% of the time
table6[1,1] = paste(names(which(table(unlist(rs3_activeset_list)) > 0.8*n_check)),collapse=",")
table6[2,1] = paste(names(which(table(unlist(rs3scad_activeset_list)) > 0.8*n_check)),collapse=",")
table6[3,1] = "" # empty
table6[4,1] = paste(names(which(table(unlist(bess_activeset_list)) > 0.8*n_check)),collapse=",")
table6[5,1] = "" # empty
table6[6,1] = paste(names(which(table(unlist(ncvreg_activeset_list)) > 0.8*n_check)), collapse = ",")
table6[7,1] = paste(names(which(table(unlist(lasso_activeset_list)) > 0.8*n_check)),collapse = ",")

table6[1,2] = round(mean(unlist(lapply(rs3_activeset_list, length))),2)
table6[2,2] = round(mean(unlist(lapply(rs3scad_activeset_list, length))),2)
table6[3,2] = round(mean(unlist(lapply(rs3fpc_activeset_list, length))),2)
table6[4,2] = round(mean(unlist(lapply(bess_activeset_list, length))),2)
table6[5,2] = round(mean(unlist(lapply(abess_activeset_list, length))),2)
table6[6,2] = round(mean(unlist(lapply(ncvreg_activeset_list, length))),2)
table6[7,2] = round(mean(unlist(lapply(lasso_activeset_list, length))),2)


table6[1,3] = round(sd(unlist(lapply(rs3_activeset_list, length)))/sqrt(n_check),2)
table6[2,3] = round(sd(unlist(lapply(rs3scad_activeset_list, length)))/sqrt(n_check),2)
table6[3,3] = round(sd(unlist(lapply(rs3fpc_activeset_list, length)))/sqrt(n_check),2)
table6[4,3] = round(sd(unlist(lapply(bess_activeset_list, length)))/sqrt(n_check),2)
table6[5,3] = round(sd(unlist(lapply(abess_activeset_list, length)))/sqrt(n_check),2)
table6[6,3] = round(sd(unlist(lapply(ncvreg_activeset_list, length)))/sqrt(n_check),2)
table6[7,3] = round(sd(unlist(lapply(lasso_activeset_list, length)))/sqrt(n_check),2)

colnames(table6) = c("Selected Predictors", "Mean","Standard Error")
rownames(table6) = c("RS3","RS3+SCAD","RS3+FPCS","BeSS","abess","SCAD","Lasso")
table6
