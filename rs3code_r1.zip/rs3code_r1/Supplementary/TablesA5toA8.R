# TablesA5toA8.R
rm(list = ls())

# Change this working directory to the location of the SimResults folder.
setwd("~/GMU/Papers in Progress/SubsetSelection/rs3code_r1/SimResults")

### Table A5 (Binomial, rho = 0.9, tau = 10)
bin_n200_active3tau10 = read.csv("med_binomialn200p500rho0.9active3blocksize10.csv")[,-c(1,4)]
bin_n200_active6tau10 = read.csv("med_binomialn200p500rho0.9active6blocksize10.csv")[,-c(1,4)]
rownames1 = c("RS3","RS3+SCAD","RS3+FPCS","Lasso","Elastic","BeSS","abess","SCAD")

tableA5 = cbind(bin_n200_active3tau10, bin_n200_active6tau10)
rownames(tableA5) = rownames1
round(tableA5,2)  # Table A5

### Table A6 (Gaussian, rho = 0.9, tau = 10)
gaus_n200_active3tau10 = read.csv("med_gaussiann200p500rho0.9active3blocksize10.csv")[,-c(1,4)]
gaus_n200_active6tau10 = read.csv("med_gaussiann200p500rho0.9active6blocksize10.csv")[,-c(1,4)]
rownames1 = c("RS3","RS3+SCAD","RS3+FPCS","Lasso","Elastic","BeSS","abess","SCAD")

tableA6 = cbind(gaus_n200_active3tau10, gaus_n200_active6tau10)
rownames(tableA6) = rownames1
round(tableA6,2)  # Table A6

### Table A7 (Binomial, rho = 0.9, tau = 15)
bin_n200_active3tau15 = read.csv("med_binomialn200p500rho0.9active3blocksize15.csv")[,-c(1,4)]
bin_n200_active6tau15 = read.csv("med_binomialn200p500rho0.9active6blocksize15.csv")[,-c(1,4)]
rownames1 = c("RS3","RS3+SCAD","RS3+FPCS","Lasso","Elastic","BeSS","abess","SCAD")

tableA7 = cbind(bin_n200_active3tau15, bin_n200_active6tau15)
rownames(tableA7) = rownames1
round(tableA7,2)  # Table A7

### Table A8 (Gaussian, rho = 0.9, tau = 15)
gaus_n200_active3tau15 = read.csv("med_gaussiann200p500rho0.9active3blocksize15.csv")[,-c(1,4)]
gaus_n200_active6tau15 = read.csv("med_gaussiann200p500rho0.9active6blocksize15.csv")[,-c(1,4)]
rownames1 = c("RS3","RS3+SCAD","RS3+FPCS","Lasso","Elastic","BeSS","abess","SCAD")

tableA8 = cbind(gaus_n200_active3tau15, gaus_n200_active6tau15)
rownames(tableA8) = rownames1
round(tableA8,2)  # Table A8