# TablesA11toA12.R
rm(list = ls())

# Change this working directory to the location of the SimResults folder.
setwd("~/GMU/Papers in Progress/SubsetSelection/rs3code_r1/SimResults")

### Table A11 (Binomial, rho = 0.9, RS3+SCAD only)
bin_n200_active3 = read.csv("RS3_SCAD_cutoff_sim_binomialn200p500rho0.9active3.csv")
colnames(bin_n200_active3) = c("k","TP","FP","BIC","Acc","CPU")
bin_n200_active6 = read.csv("RS3_SCAD_cutoff_sim_binomialn200p500rho0.9active6.csv")[,-1]

tableA11 = cbind(bin_n200_active3, bin_n200_active6)
round(tableA11,2)  # Table A11

### Table A6 (Gaussian, rho = 0.9, RS3+SCAD only)
gaus_n200_active3 = read.csv("RS3_SCAD_cutoff_sim_gaussiann200p500rho0.9active3.csv")
colnames(gaus_n200_active3) = c("k","TP","FP","BIC","MSPE","CPU")
gaus_n200_active6 = read.csv("RS3_SCAD_cutoff_sim_gaussiann200p500rho0.9active6.csv")[,-1]

tableA12 = cbind(gaus_n200_active3, gaus_n200_active6)
round(tableA12,2)  # Table A12
