# TableA13.R
rm(list = ls())

# Change this working directory to the location of the SimResults folder.
setwd("~/GMU/Papers in Progress/SubsetSelection/rs3code_r1/SimResults")

cutoff0.3acc = read.csv("med_binomialn200p500rho0.9active6cutoff0.3.csv")[,6]
cutoff0.4acc = read.csv("med_binomialn200p500rho0.9active6cutoff0.4.csv")[,6]
cutoff0.5acc = read.csv("med_binomialn200p500rho0.9active6.csv")[,6]
cutoff0.6acc = read.csv("med_binomialn200p500rho0.9active6cutoff0.6.csv")[,6]
cutoff0.7acc = read.csv("med_binomialn200p500rho0.9active6cutoff0.7.csv")[,6]

tableA13 = cbind(cutoff0.3acc, cutoff0.4acc, cutoff0.5acc,
                 cutoff0.6acc, cutoff0.7acc)
rownames(tableA13) = c("RS3", "RS3+SCAD", "RS3+FPCS", "Lasso",
                       "Elastic", "BeSS", "abess", "SCAD")
round(tableA13,2) # Table A13
