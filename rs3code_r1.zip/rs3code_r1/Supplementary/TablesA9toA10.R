# TablesA9toA10.R
rm(list = ls())

# Change this working directory to the location of the SimResults folder.
setwd("~/GMU/Papers in Progress/SubsetSelection/rs3code_r1/SimResults")

### Table A9 (Binomial)
bin_n200_active9_med = read.csv("med_binomialn200p500rho0.9active9.csv")[,-c(1,4)]
bin_n200_active9_mean = read.csv("mean_binomialn200p500rho0.9active9.csv")[,-1]
rownames1 = c("RS3","RS3+SCAD","RS3+FPCS","Lasso","Elastic","BeSS","abess","SCAD")

tableA9 = matrix(NA, nrow = 8, ncol = 5)
for(i in 1:8){
  for(j in 1:5){
    tableA9[i,j] = paste( round(bin_n200_active9_med[i,j],2), " ( ",
                          round(bin_n200_active9_mean[i,j],2), " )", sep = "" )
  }
}

rownames(tableA9) = rownames1
colnames(tableA9) = colnames(bin_n200_active9_mean)
tableA9 # Table A9


### Table A10 (Gaussian)
gaus_n200_active9_med = read.csv("med_gaussiann200p500rho0.9active9.csv")[,-c(1,4)]
gaus_n200_active9_mean = read.csv("mean_gaussiann200p500rho0.9active9.csv")[,-1]
rownames1 = c("RS3","RS3+SCAD","RS3+FPCS","Lasso","Elastic","BeSS","abess","SCAD")

tableA10 = matrix(NA, nrow = 8, ncol = 5)
for(i in 1:8){
  for(j in 1:5){
    tableA10[i,j] = paste( round(gaus_n200_active9_med[i,j],2), " ( ",
                          round(gaus_n200_active9_mean[i,j],2), " )", sep = "" )
  }
}

rownames(tableA10) = rownames1
colnames(tableA10) = colnames(gaus_n200_active9_mean)
tableA10 # Table A10

