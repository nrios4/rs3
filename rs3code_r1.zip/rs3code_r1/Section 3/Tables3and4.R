# Table1.R
rm(list = ls())

# Change this working directory to the location of the rs3code file.
setwd("~/GMU/Papers in Progress/SubsetSelection/rs3code_r1") 

bin_n200_active3 = read.csv("med_binomialn200p500rho0.9active3halfbinary.csv")[,-c(1,4)]
bin_n200_active6 = read.csv("med_binomialn200p500rho0.9active6halfbinary.csv")[,-c(1,4)]
rownames1 = c("RS3","RS3+SCAD","RS3+FPCS","Lasso","Elastic","BeSS","abess","SCAD")

table3 = cbind(bin_n200_active3, bin_n200_active6)
rownames(table3) = rownames1
round(table3,2)  # Table 3

gaus_n200_active3 = read.csv("med_gaussiann200p500rho0.9active3halfbinary.csv")[,-c(1,4)]
gaus_n200_active6 = read.csv("med_gaussiann200p500rho0.9active6halfbinary.csv")[,-c(1,4)]
rownames1 = c("RS3","RS3+SCAD","RS3+FPCS","Lasso","Elastic","BeSS","abess","SCAD")

table4 = cbind(gaus_n200_active3, gaus_n200_active6)
rownames(table4) = rownames1
round(table4,2)  # Table 4
