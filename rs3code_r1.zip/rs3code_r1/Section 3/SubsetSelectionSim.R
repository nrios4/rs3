# SubsetSelection.R

rm(list = ls()) # clear the environment

library(mvtnorm)
library(glmnet)
library(BeSS)
library(stringr)
library(ncvreg)
library(abess)
library(future)
library(future.apply)
library(caret)

colSdColMeans <- function(x, na.rm=F) {
  if (na.rm) {
    n <- colSums(!is.na(x)) # thanks @flodel
  } else {
    n <- nrow(x)
  }
  colVar <- colMeans(x*x, na.rm=na.rm) - (colMeans(x, na.rm=na.rm))^2
  return(sqrt(colVar * n/(n-1)))
}

# simulate_dataset
# n: number of data points
# beta: a vector of p covariates
# family: either "gaussian" or "binomial" (gaussian by default)
# rho: controls the correlation among predictors (0.1 by default)
# sigma2: error variance (0.05 by default)
# compound: if TRUE, uses compound symmetry to find the variance (default is FALSE)
# 
# returns a data frame with n rows, p predictors (x1, ..., xp), and a response (y)
# If family = gaussian, then OLS regression with normal errors are used to find the responses
# If family = binomial, a logistic regression model is fit and sigma2 is not used
# is used to find the responses

simulate_dataset <- function(n, beta, family = "gaussian",
                             sigma2 = 0.05, rho = 0.1, compound = FALSE){
  
  p <- length(beta)
  sigma_mat <- diag(p)
  
  if(compound){
  
    sigma_mat = (1-rho)*diag(p) + rho*matrix(1,p,p)
      
      
  } else{
  
    for(i in 1:p){
    for(j in 1:p){
      if(i != j & abs(i-j) <= 5){
        sigma_mat[i,j] = sigma_mat[i,j] + rho
      }
    }
  }
      
      
      
  }
  

  
  X = rmvnorm(n, mean = rep(0,p), sigma = sigma_mat)
  err_vec = rnorm(n, mean = 0, sd = sqrt(sigma2))
  if(family == "gaussian"){
    y = cbind(1,X)%*%c(1,beta) + err_vec
  }
  if(family == "binomial"){
    # lin_preds = cbind(1,X)%*%c(1,beta) + err_vec
    lin_preds = cbind(1,X)%*%c(1,beta)
    prob_vec = exp(lin_preds)/(1+exp(lin_preds))
    y = rbinom(n, size = 1, prob = prob_vec)
  }
  df_out = as.data.frame(cbind(X,y))
  colnames(df_out) = c(paste("X",1:p, sep = ""),"y")
  return(df_out)
  
}

# rs3_fixed_subset_size
# helper function for rs3
# is just rs3 for a fixed subset size b
rs3_fixed_subset_size <- function(subset_size, weights, Xmat, y, family, block_size, n_split = 30, n_search = 500){
  X = Xmat
  n = nrow(X)
  p = ncol(X)
  # print(paste("Subset size",subset_size, sep = ": "))
  # print("Finding candidate subsets.")
  all_samp_preds = matrix(NA, nrow = n_search, ncol = subset_size)
  losses = numeric(n_search)
  for(s in 1:n_search){
    samp_preds = sample(1:p, subset_size, prob = weights)
    glm_m1 = glm(y ~ X[,samp_preds], family = family)
    all_samp_preds[s,] = samp_preds
    losses[s] = BIC(glm_m1)
  }
  min_ind = which.min(losses)
  smallest_loss = losses[min_ind]
  best_sol = all_samp_preds[min_ind,]
  return(list(best_sol, smallest_loss))
  
}


# get_randomized_blocks
# helper function for RS3
# Inputs:
#     Xmat (n by p matrix of predictors)
#     n_blocks (number of blocks)
# Output: a vector of the same length of current_predictors that randomly assigns current_predictors into blocks of equal size
get_randomized_blocks <- function(Xmat, n_blocks){
  p <- ncol(Xmat)
  block_assignments <- numeric(p)
  block_size = p/n_blocks
  
  # Step 1: Randomly select 1 predictor for each block
  initial_inds <- sample(1:p,n_blocks, replace = FALSE)
  block_assignments[initial_inds] <- 1:n_blocks
  
  # Step 2: iterate over current predictors
  for(j in 1:p){
    # if the predictor has not assigned a block yet...
    if(block_assignments[j] == 0){
      # compute probability weights for each block based on the correlation
      prob_weights <- sapply(1:n_blocks, function(x) 1/max(cor(Xmat[,j],Xmat[,block_assignments == x])^2)  )
      # if the block is full, set assignment probability to 0
      prob_weights <- sapply(1:n_blocks, function(x) ifelse(sum(block_assignments == x) == block_size, 0, prob_weights[x]))
      random_block <- sample(1:n_blocks, 1, prob = prob_weights)
      # place predictor in the assigned block
      block_assignments[j] <- random_block
    }
  }
  
  
  return(block_assignments)
  
}


# Randomized Smart Subset Selection (RS3)
# Inputs:
# X (n by p matrix of predictors)
# y (vector of n resposnes)
# family ("gaussian" or "binomial")
# p_max (maximum subset size, default is 10)
# n_split: number of times the predictors are split (to search for weights), default is 100
# n_search: number of candidates for the best subset
# n_workers: number of workers for future_apply() parallel backend (default is 10)
rs3 <- function(X, y, family, block_size, p_max = 10, n_split = 30, n_search = 500,
                n_workers = 5){
  n = nrow(X)
  p = ncol(X)
  if(p %% block_size != 0){
    stop("Number of predictors is not divisible by block_size.")
  }
  n_blocks = p/block_size
  if(block_size > n){
    stop("Block size is larger than n.")
  }
  if(length(y) != n){
    stop("Number of observations in X and y do not match.")
  }
  zscores_mat = matrix(NA, nrow = n_split, ncol = p)
  # print("Estimating weights.")
  for(t in 1:n_split){
    pred_block_labels = as.numeric(cut(sample(1:p), n_blocks))
    # pred_block_labels = get_randomized_blocks(Xmat = X, n_blocks = n_blocks)
    for(b in 1:n_blocks){
      block_inds = which(pred_block_labels == b)
      glm_tmp = glm(y ~ X[,block_inds], family = family)
      zscores_mat[t,block_inds] = abs(coef(summary(glm_tmp))[-1,3])
    }
  }
  zscores = apply(zscores_mat, 2, median)
  w = exp(zscores^2/2)
  w = w/sum(w)
  # print("Weight estimates found.")
  losses = numeric(p_max)
  optimal_subsets = list()
  plan("multisession", workers = n_workers)
  loop.out = future_sapply(X = 1:p_max, FUN = rs3_fixed_subset_size, w = w,
                           Xmat = X, y = y, family = family, block_size = block_size, 
                           n_split = n_split, n_search = n_search, simplify = FALSE,
                           future.seed = TRUE)
  for(i in 1:p_max){
    optimal_subsets[[i]] = loop.out[[i]][[1]]
    losses[i] = loop.out[[i]][[2]]
    
  }
  min_ind = which.min(losses)
  best_subset = optimal_subsets[[min_ind]]
  return(best_subset)
}





# Randomized Smart Subset Selection (RS3) Adaptive
# Inputs:
# X (n by p matrix of predictors)
# y (vector of n resposnes)
# family ("gaussian" or "binomial")
# n_split: number of times the predictors are split (to search for weights), default is 100
# method = "lasso" or "SCAD" or "FPC" (default is SCAD)
# parallel: If true, uses future_apply() parallel backend for FPC.
# n_workers: number of workers for future_apply() parallel backend. Default is 5.
rs3_adaptive <- function(X, y, family, block_size, n_split = 100, method = "SCAD", parallel = FALSE, n_workers = 5){
  n = nrow(X)
  p = ncol(X)
  if(p %% block_size != 0){
    stop("Number of predictors is not divisible by block_size.")
  }
  n_blocks = p/block_size
  if(block_size > n){
    stop("Block size is larger than n.")
  }
  if(length(y) != n){
    stop("Number of observations in X and y do not match.")
  }
  zscores_mat = matrix(NA, nrow = n_split, ncol = p)
  print("Estimating weights.")
  for(t in 1:n_split){
    pred_block_labels = as.numeric(cut(sample(1:p), n_blocks))
    # pred_block_labels = get_randomized_blocks(Xmat = X, n_blocks = n_blocks)
    for(b in 1:n_blocks){
      block_inds = which(pred_block_labels == b)
      glm_tmp = glm(y ~ X[,block_inds], family = family)
      zscores_mat[t,block_inds] = abs(coef(summary(glm_tmp))[-1,3])
    }
  }
  # plan("multisession", workers = n_workers)
  # loop.out0 = future_sapply(X = 1:n_split, FUN = sample_zscores, Xmat = X,
  #                          y = y, family = family, n_blocks = n_blocks,
  #                          future.seed = TRUE, simplify = FALSE)
  # zscores_mat = t(simplify2array(loop.out0))
  zscores = apply(zscores_mat,2,median)
  # zscores = apply(zscores_mat, 2, function(x) quantile(x,0.9))
  w = exp(zscores^2/2)
  w = w/sum(w)
  print("found importance weights")
  
  p_cutoff = floor(1.5*n/log(n))
  sorted_preds = sort(w, decreasing = TRUE, index.return = T)$ix
  selected_preds = sorted_preds[1:p_cutoff]
  print("selected predictors")
  print(selected_preds)
  print("index of true predictors among selected predictors")
  print(match(active_set, selected_preds))
  
  X2 = X[,selected_preds]
  
  # now use adaptive lasso or SCAD
  if(method == "lasso"){
    cv_lasso <- cv.glmnet(x = X2, y = y, family = family)
    best_lambda <- cv_lasso$lambda.min
    lasso_fit <- glmnet(x = X2, y = y,
                        lambda = best_lambda, family = family)
    lasso_active_set <- selected_preds[which(abs(lasso_fit$beta) > 0)]
    return(lasso_active_set)
  } 
  if(method == "SCAD"){
    out_cv_ncvreg <- cv.ncvreg(X = X2, y = y, family = family, penalty = "SCAD")
    ncvreg_beta <- coef(out_cv_ncvreg, s = "lambda.min")[-1]
    ncvreg_active_set <- selected_preds[which(abs(ncvreg_beta) > 0)]
    return(ncvreg_active_set)
  }
  if(method == "FPC"){
    n_subsample <- 100
    # proportion of data to remove
    if(family == "gaussian"){
      prop <- 0.3 
    }
    if(family == "binomial"){
      prop <- 0.05
    }
    p_selected <- length(selected_preds)
    # positive <- rep(0, p_selected)
    # negative <- rep(0, p_selected)
    if(parallel){
      plan("multisession", workers = n_workers)
    } else{
      plan("sequential")
    }
    fpc_helper <- function(i,y, X2, family,prop,n,p_selected){
      positive <- rep(0, p_selected)
      negative <- rep(0, p_selected)
      remove <- sample(c(1:n), prop * n)
      Y.sample <- y[-remove]
      X.sample <- X2[-remove,]
      out_cv_ncvreg <- cv.ncvreg(X = X.sample, y = Y.sample, family = family, penalty = "SCAD")
      beta_best <- as.vector(coef(out_cv_ncvreg, s = "lambda.min")[-1])
      positive <- positive + (beta_best >= 0)
      negative <- negative + (beta_best <= 0)
      return(rbind(positive,negative))
    }
    loop.out = future_sapply(X = 1:n_subsample, FUN = fpc_helper, y=y,X2=X2,family=family,
                             prop=prop,n=n,p_selected = p_selected,
                             simplify = FALSE,future.seed = TRUE)
    positive <- rep(0, p_selected)
    negative <- rep(0, p_selected)
    for(i in 1:n_subsample){
      positive <- positive + loop.out[[i]][1,]
      negative <- negative + loop.out[[i]][2,]
    }
    index <- selected_preds[which(as.vector(positive / negative) %in% c(Inf, 0))]
    # for (i in 1:n_subsample) {
    #   remove <- sample(c(1:n), prop * n)
    #   Y.sample <- y[-remove]
    #   X.sample <- X2[-remove,]
    #   
    #   cv_lasso <- cv.glmnet(x = X.sample, y = Y.sample, family = family, alpha = 1, nfolds = 10)
    #   best_lambda <- cv_lasso$lambda.min
    #   lasso_fit <- glmnet(x = X.sample, y = Y.sample, lambda = best_lambda, family = family)
    #   beta_best <- as.vector(lasso_fit$beta)
    #   
    #   positive <- positive + (beta_best >= 0)
    #   negative <- negative + (beta_best <= 0)
    # }
    # index <- selected_preds[which(as.vector(positive / negative) %in% c(Inf, 0))]
    
    out_cv_ncvreg <- cv.ncvreg(X = X[,index], y = y, family = family, penalty = "SCAD")
    ncvreg_beta <- coef(out_cv_ncvreg, s = "lambda.min")[-1]
    ncvreg_active_set <- index[which(abs(ncvreg_beta) > 0)]
    return(ncvreg_active_set)
  }
}



# returns a vector of summary statistics for a given estimated subset
summarize_performance <- function(estimated_active_set,active_set, full_data, test_data, family){
  
  TP = sum(active_set %in% estimated_active_set)
  FP = sum(!(estimated_active_set %in% active_set))
  pplus1 = ncol(full_data)
  df_fit = full_data[,c(estimated_active_set,pplus1)]
  glm_fit = glm(y ~ ., family = family, data = df_fit)
  AIC_model = AIC(glm_fit)
  BIC_model = BIC(glm_fit)
  predvals = predict(glm_fit, test_data, type = "response")
  if(family == "binomial"){
    accuracy = mean((predvals > 0.5) == test_data$y)
    res.vec = c(TP,FP,AIC_model, BIC_model,accuracy)
    names(res.vec) = c("TP","FP","AIC","BIC","Acc")
  }
  else{
    MSPE = mean((test_data$y - predvals)^2)
    res.vec = c(TP,FP,AIC_model, BIC_model,MSPE)
    names(res.vec) = c("TP","FP","AIC","BIC","MSPE")
  }
  return(res.vec)
  
}


set.seed(123)
n = 200 # number of data points
p = 500 # number of predictors
p_active = 6 # number of active predictors (3,6)
family = "gaussian"
# family = "binomial"
rho = 0 # 0, 0.5, 0.9
sigma2 = 1 
n_sim = 100
n_test = 100
compound = FALSE # if TRUE, use the compound symmetry covariance

n_split = 60 
n_workers = 20

if(compound){
    namevec <- paste(family,"n",n,"p",p,"rho",rho,"active",p_active,"compound.csv",sep="")
} else{
 namevec <- paste(family,"n",n,"p",p,"rho",rho,"active",p_active,".csv",sep="")   
}


rs3_results <- matrix(NA, nrow = n_sim, ncol = 6)
rs3_adaptive_results <- matrix(NA, nrow = n_sim, ncol = 6)
rs3_adafpc_results <- matrix(NA, nrow = n_sim, ncol = 6)
lasso_results <- matrix(NA, nrow = n_sim, ncol = 6)
elastic_results <- matrix(NA, nrow = n_sim, ncol = 6)
bess_results <- matrix(NA, nrow = n_sim, ncol = 6)
abess_results <- matrix(NA, nrow = n_sim, ncol = 6)
ncvreg_results <- matrix(NA, nrow = n_sim, ncol = 6)

beta <- numeric(p)
active_set = sort(sample(1:p, p_active))

if(family == "gaussian"){
  beta[active_set] = rnorm(p_active, mean = 1, sd = 0.01)*sample(c(-1,1),p_active,replace=T)
}
if(family == "binomial"){
  beta[active_set] = rnorm(p_active, mean = sqrt(3), sd = 0.01)*sample(c(-1,1),p_active,replace=T)
}


for(iter in 1:n_sim){
  n.try <- 0
  while(TRUE){
    n.try <- n.try + 1
    try.res <- tryCatch(
      {
        df_sim = simulate_dataset(n, beta, family, sigma2, rho, compound = compound)
        Xmat = as.matrix(df_sim[,-(p+1)])
        ymat = as.matrix(df_sim[,p+1])
        
        test_data = simulate_dataset(n_test, beta, family, sigma2, rho, compound = compound)
        
        # proposed method
        rs3_start_time <- Sys.time()
        rs3_active_set <- rs3(X = Xmat, y = ymat, family = family, block_size = 25, p_max = 15,
                              n_split = n_split, n_search = 100, n_workers = 10)
        rs3_end_time <- Sys.time()
        rs3_cpu <- as.numeric(rs3_end_time - rs3_start_time, units = "secs")
        
        # rs3_adaptive
        rs3_adaptive_start_time <- Sys.time()
        rs3_adaptive_active_set <- rs3_adaptive(X = Xmat, y = ymat, family = family,
                                                block_size = 25, n_split = n_split, method = "SCAD")
        rs3_adaptive_end_time <- Sys.time()
        rs3_adaptive_cpu <- as.numeric(rs3_adaptive_end_time - rs3_adaptive_start_time, units = "secs")
        
        # rs3_adaptive with false positive control
        rs3_adafpc_start_time <- Sys.time()
        rs3_adafpc_active_set <- rs3_adaptive(X = Xmat, y = ymat, family = family,
                                              block_size = 25, n_split = n_split, method = "FPC",parallel = TRUE, n_workers = n_workers)
        rs3_adafpc_end_time <- Sys.time()
        rs3_adafpc_cpu <- as.numeric(rs3_adafpc_end_time - rs3_adafpc_start_time, units = "secs")
        
        
        # check lasso (glmnet)
        lasso_start_time <- Sys.time()
        cv_lasso <- cv.glmnet(x = Xmat, y = ymat, family = family)
        best_lambda <- cv_lasso$lambda.min
        lasso_fit <- glmnet(x = Xmat, y = ymat,
                            lambda = best_lambda, family = family)
        lasso_active_set <- which(abs(lasso_fit$beta) > 0)
        lasso_end_time <- Sys.time()
        lasso_cpu <- as.numeric(lasso_end_time - lasso_start_time, units = "secs")
        
        
        # check elastic net
        if(family == "binomial"){
          ymat2 = as.factor(ymat)
        } else{
          ymat2 = as.vector(ymat)
        }
        
        elastic_start_time <- Sys.time()
        cv5 = trainControl(method = "cv", number = 5)
        cv_elasticnet <- train(x = Xmat, y = ymat2, method = "glmnet",
                               family = family, trControl = cv5)
        best_alpha = as.numeric(cv_elasticnet$bestTune[1])
        best_lambda = as.numeric(cv_elasticnet$bestTune[2])
        elasticnet_fit = glmnet(x = Xmat, y = ymat, family = family, alpha = best_alpha, 
                                lambda = best_lambda)
        elastic_active_set <- which(abs(elasticnet_fit$beta) > 0)
        elastic_end_time <- Sys.time()
        elastic_cpu <- as.numeric(elastic_end_time - elastic_start_time, units = "secs")
        
        # check BeSS (https://www.jstatsoft.org/article/view/v094i04)
        bess_start_time <- Sys.time()
        out_bess <- bess(x = Xmat, y = ymat, family = family)
        bess_active_set <- as.numeric(unlist(str_extract_all(names(coef(out_bess$bestmodel)[-1]), "[0-9]+")))
        bess_end_time <- Sys.time()
        bess_cpu <- as.numeric(bess_end_time - bess_start_time, units = "secs")
        
        # check abess ( Zhu J, Wang X, Hu L, Huang J, Jiang K, Zhang Y, Lin S, Zhu J (2022). 'abess: A Fast Best Subset Selection Library in Python and R.' Journal of Machine Learning Research, 23(202), 1-7. https://www.jmlr.org/papers/v23/21-1060.html.)
        abess_start_time <- Sys.time()
        out_abess <- abess(x = Xmat, y = ymat, family = family)
        abess_beta <- extract(out_abess, out_abess$best.size)$beta
        abess_active_set <- which(abess_beta != 0)
        abess_end_time <- Sys.time()
        abess_cpu <- as.numeric(abess_end_time - abess_start_time , units = "secs")
        
        print("abess: index of true predictors among selected predictors")
        print(match(active_set, abess_active_set))
        
        
        # check SCAD (https://pmc.ncbi.nlm.nih.gov/articles/PMC3212875/pdf/nihms332857.pdf)
        # doesn't work for saturated model, so first use marginal filtering
        ncvreg_start_time <- Sys.time()
        abs_zscores = numeric(p)
        for(j in 1:p){
          tmp_df = data.frame(y = ymat,x = Xmat[,j])
          marginal_glm = glm(y ~ x, data = tmp_df)
          abs_zscores[j] = abs(coef(summary(marginal_glm))[-1,3])
        }
        # now choose the top n/2 scores
        sorted_inds = sort(abs_zscores, index.return = TRUE, decreasing = TRUE)$ix
        top_preds = sorted_inds[1:floor(0.5*n)]
        X2 = Xmat[,top_preds]
        out_cv_ncvreg <- cv.ncvreg(X = X2, y = ymat, family = family, penalty = "SCAD")
        ncvreg_beta <- coef(out_cv_ncvreg, s = "lambda.min")[-1]
        ncvreg_active_set <- top_preds[which(abs(ncvreg_beta) > 0)]
        ncvreg_end_time <- Sys.time()
        ncvreg_cpu <- as.numeric(ncvreg_end_time - ncvreg_start_time, units = "secs")
        
        rs3_results[iter,] <- c(summarize_performance(rs3_active_set, active_set = active_set, full_data = df_sim, test_data = test_data, family = family), rs3_cpu)
        rs3_adaptive_results[iter,] <- c(summarize_performance(rs3_adaptive_active_set, active_set = active_set, full_data = df_sim, test_data = test_data, family = family), rs3_adaptive_cpu)
        rs3_adafpc_results[iter,] <- c(summarize_performance(rs3_adafpc_active_set, active_set = active_set, full_data = df_sim, test_data = test_data, family = family), rs3_adafpc_cpu)
        lasso_results[iter,] <- c(summarize_performance(lasso_active_set, active_set = active_set, full_data = df_sim, test_data = test_data, family = family), lasso_cpu)
        elastic_results[iter,] <- c(summarize_performance(elastic_active_set, active_set = active_set, full_data = df_sim, test_data = test_data, family = family), elastic_cpu)
        bess_results[iter,] <- c(summarize_performance(bess_active_set, active_set = active_set, full_data = df_sim, test_data = test_data, family = family), bess_cpu)
        abess_results[iter,] <- c(summarize_performance(abess_active_set, active_set = active_set, full_data = df_sim, test_data = test_data, family = family), abess_cpu)
        ncvreg_results[iter,] <- c(summarize_performance(ncvreg_active_set, active_set = active_set, full_data = df_sim, test_data = test_data, family = family), ncvreg_cpu)
        
      }, 
      error = function(e) { 
        print(e)
        'try-error'
      }
    )
    if(length(try.res) > 1) break
    if(n.try > 20) stop("Tried many times; try to resubmit the job.")
  }
}

res_df = rbind(colMeans(rs3_results),colMeans(rs3_adaptive_results),colMeans(rs3_adafpc_results),
               colMeans(lasso_results), colMeans(elastic_results),
               colMeans(bess_results), colMeans(abess_results), colMeans(ncvreg_results))
rownames(res_df) = c("rs3","rs3_adaptive","rs3_adafpc","lasso","elastic","bess","abess","SCAD")
if(family == "binomial"){
  colnames(res_df) = c("TP","FP","AIC","BIC","Acc","CPU Time")
} else{
  colnames(res_df) = c("TP","FP","AIC","BIC","MSPE","CPU Time")
}

res_df_meds = rbind(apply(rs3_results,2,median),
                    apply(rs3_adaptive_results,2,median),
                    apply(rs3_adafpc_results,2,median),
                    apply(lasso_results,2,median),
                    apply(elastic_results,2,median),
                    apply(bess_results,2,median),
                    apply(abess_results,2,median),
                    apply(ncvreg_results,2,median)
)
colnames(res_df_meds) = colnames(res_df)
# write.csv(res_df, namevec)

all_results <- rbind(rs3_results, rs3_adaptive_results, rs3_adafpc_results,
                     lasso_results, elastic_results, bess_results, abess_results, ncvreg_results)
colnames(all_results) = colnames(res_df)
all_results_df = data.frame(all_results, method = c(rep("rs3",n_sim),
                                                    rep("rs3+SCAD",n_sim),
                                                    rep("rs3+FPCS",n_sim),
                                                    rep("lasso",n_sim),
                                                    rep("elastic",n_sim),
                                                    rep("BeSS",n_sim),
                                                    rep("abess",n_sim),
                                                    rep("SCAD",n_sim)))

write.csv(all_results_df, paste("ALL_",namevec, sep = ""))
write.csv(res_df_meds,paste("med_",namevec, sep = ""))
