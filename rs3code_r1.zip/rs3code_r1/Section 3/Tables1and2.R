# Table1.R
rm(list = ls())

# Change this working directory to the location of the rs3code file.
setwd("~/GMU/Papers in Progress/SubsetSelection/rs3code") 

bin_n200_active3 = read.csv("med_binomialn200p500rho0.9active3.csv")[,-c(1,4)]
bin_n200_active6 = read.csv("med_binomialn200p500rho0.9active6.csv")[,-c(1,4)]
rownames1 = c("RS3","RS3+SCAD","RS3+FPCS","Lasso","Elastic","BeSS","abess","SCAD")

table1 = cbind(bin_n200_active3, bin_n200_active6)
rownames(table1) = rownames1
round(table1,2)  # Table 1

gaus_n200_active3 = read.csv("med_gaussiann200p500rho0.9active3.csv")[,-c(1,4)]
gaus_n200_active6 = read.csv("med_gaussiann200p500rho0.9active6.csv")[,-c(1,4)]
rownames1 = c("RS3","RS3+SCAD","RS3+FPCS","Lasso","Elastic","BeSS","abess","SCAD")

table2 = cbind(gaus_n200_active3, gaus_n200_active6)
rownames(table2) = rownames1
round(table2,2)  # Table 2
